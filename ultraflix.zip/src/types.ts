export interface Plan {
  id: string;
  title: string;
  price: number;
  durationText: string;
  features: string[];
  badge?: string;
  savingsText?: string;
  recommended?: boolean;
  pixCode?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  avatarUrl?: string;
  location: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export type PaymentMethod = "pix" | "card";

export interface CheckoutForm {
  name: string;
  phone: string;
  paymentMethod: PaymentMethod;
  cardNumber?: string;
  cardName?: string;
  cardExpiry?: string;
  cardCvv?: string;
}
