import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Tv, Sparkles, ChevronRight, ShieldCheck, Zap, Star, Play, Film, Flame, Trophy } from "lucide-react";

interface HeroProps {
  onScrollToPlans: () => void;
}

const SPOTLIGHTS = [
  {
    title: "LANÇAMENTOS EXCLUSIVOS",
    badge: "Cinema em Casa",
    desc: "Acesso simultâneo aos maiores blockbusters de Hollywood recém-saídos das salas de cinema diretamente para a sua tela.",
    image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&q=80",
    rating: "9.8",
    tags: ["Filmes", "4K Ultra HD", "Sucesso de Bilheteria"]
  },
  {
    title: "FUTEBOL E ESPORTES AO VIVO",
    badge: "Transmissão Sem Delay",
    desc: "Não perca um segundo do campeonato brasileiro, Champions League e as lutas mais aguardadas do ano com estabilidade absoluta.",
    image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=1200&q=80",
    rating: "10",
    tags: ["Esportes", "60 FPS", "Ao Vivo"]
  },
  {
    title: "SÉRIES COMPLETAS",
    badge: "Maratona Garantida",
    desc: "Temporadas inteiras dubladas e legendadas para você e toda a sua família curtirem sem propagandas ou interrupções.",
    image: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?auto=format&fit=crop&w=1200&q=80",
    rating: "9.6",
    tags: ["Séries", "Temporadas Completas", "Dublado / Legendado"]
  }
];

export default function Hero({ onScrollToPlans }: HeroProps) {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % SPOTLIGHTS.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const current = SPOTLIGHTS[activeIndex];

  return (
    <section className="relative min-h-screen pt-20 pb-16 flex flex-col items-center justify-center overflow-hidden bg-[#050505]">
      
      {/* BACKGROUND SPOTLIGHT LAYER */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeIndex}
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 0.45, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
          >
            <img
              src={current.image}
              alt={current.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center filter brightness-[0.7] saturate-100"
            />
          </motion.div>
        </AnimatePresence>

        {/* Cinematic rich premium gradients overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/80 to-[#050505]/45" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/20 to-[#050505]" />
        
        {/* Dynamic ambient pulsing red neon glow */}
        <motion.div 
          animate={{ opacity: [0.12, 0.22, 0.12] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-1/4 left-1/2 -translate-x-1/2 w-[90%] h-[40%] bg-red-600/20 blur-[130px] rounded-full pointer-events-none" 
        />
        <div className="absolute top-20 left-10 w-64 h-64 bg-red-600/5 blur-[100px] rounded-full pointer-events-none" />
      </div>

      {/* CONTENT INTERACTION GRID */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 mt-8 flex flex-col lg:flex-row items-center gap-10 lg:gap-14">
        
        {/* LEFT COLUMN: HERO OFFERS & DIRECT VALUE PROPOSITION */}
        <div className="w-full lg:w-[55%] text-center lg:text-left flex flex-col items-center lg:items-start">
          
          {/* Animated Premium Badge */}
          <motion.div 
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center space-x-2 bg-red-950/45 border border-red-500/30 px-4 py-1.5 rounded-full mb-6 backdrop-blur-md"
          >
            <Sparkles className="w-3.5 h-3.5 text-red-500 fill-red-500" />
            <span className="font-mono text-[10px] sm:text-xs font-semibold tracking-widest text-red-400 uppercase">
              PLANO ATIVO IMEDIATO • SUPORTE 24H
            </span>
          </motion.div>

          {/* Big Cinematic Title */}
          <motion.h1 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="font-display font-extrabold text-3.5xl sm:text-5xl md:text-6xl text-white tracking-tight leading-[1.08] mb-6 max-w-3xl"
          >
            SEU ENTRETENIMENTO COMPLETO EM UM <span className="text-red-600 text-shadow-neon uppercase block sm:inline">ÚNICO LUGAR</span>
          </motion.h1>

          {/* Core Subtitle */}
          <motion.p 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="font-sans text-sm sm:text-lg text-gray-300 max-w-xl leading-relaxed mb-8 px-2 sm:px-0"
          >
            Filmes de cinema, séries consagradas, esportes ao vivo com imagem em qualidade cinematográfica 4K. Ative hoje e mude para sempre sua experiência de tela.
          </motion.p>

          {/* Big Red Magnetic Button */}
          <motion.button
            onClick={onScrollToPlans}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            id="btn_hero_assinar"
            className="group relative inline-flex items-center justify-center bg-red-600 hover:bg-red-700 text-white font-display font-black text-sm sm:text-base px-8 py-4.5 sm:px-11 sm:py-5 rounded-full shadow-xl shadow-red-600/40 hover:shadow-red-600/65 transition-all duration-350 uppercase tracking-widest cursor-pointer overflow-hidden mb-8"
          >
            <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-[shimmer_1.8s_infinite]" />
            <span className="relative flex items-center space-x-2.5">
              <span>QUERO ASSINAR AGORA</span>
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </span>
          </motion.button>

          {/* Live Platform Security badges */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 sm:gap-6 text-gray-400 font-sans text-xs sm:text-sm">
            <div className="flex items-center space-x-1.5 bg-gray-950/40 px-3 py-1.5 rounded-lg border border-gray-900/40">
              <Zap className="w-4 h-4 text-red-500 fill-red-500/20" />
              <span>Ativação Instantânea</span>
            </div>
            <div className="flex items-center space-x-1.5 bg-gray-950/40 px-3 py-1.5 rounded-lg border border-gray-900/40">
              <ShieldCheck className="w-4 h-4 text-red-500 fill-red-500/20" />
              <span>Suporte Especializado</span>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: INTERACTIVE STREAMING CATALOG HIGHLIGHTS (Feels like Netflix Billboard) */}
        <div className="w-full lg:w-[45%] flex flex-col items-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, type: "spring", stiffness: 100 }}
            className="w-full bg-[#0d0d0d] border border-gray-900/80 rounded-2.5xl overflow-hidden shadow-2xl shadow-red-600/5 backdrop-blur-md flex flex-col justify-between"
          >
            {/* Spotlight Banner header */}
            <div className="relative h-44 sm:h-52 overflow-hidden">
              <AnimatePresence mode="wait">
                <motion.img
                  key={activeIndex}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  src={current.image}
                  alt={current.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </AnimatePresence>
              <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-black/35" />
              
              {/* Dynamic Tag */}
              <div className="absolute top-4 left-4 bg-red-600 px-3 py-1 rounded-full text-[10px] font-display font-black tracking-widest text-white uppercase shadow-md shadow-red-600/30">
                ★ {current.badge}
              </div>

              {/* Streaming Live Badge with pulse effect */}
              <div className="absolute top-4 right-4 flex items-center space-x-1.5 bg-black/60 backdrop-blur-sm px-2.5 py-1 rounded-lg">
                <span className="w-2 h-2 bg-red-500 rounded-full animate-ping" />
                <span className="font-mono text-[9px] font-extrabold text-white uppercase tracking-wider">LIVE</span>
              </div>
            </div>

            {/* Content info area */}
            <div className="p-6 space-y-4">
              
              {/* Tabs list to toggle */}
              <div className="flex space-x-2 overflow-x-auto pb-1 scrollbar-none">
                {SPOTLIGHTS.map((s, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveIndex(idx)}
                    className={`px-3 py-1.5 rounded-lg font-display font-bold text-[10px] tracking-wider uppercase shrink-0 transition-all duration-200 cursor-pointer ${
                      idx === activeIndex 
                        ? "bg-red-950/60 border border-red-600/50 text-white shadow-md shadow-red-600/10"
                        : "bg-[#121212] border border-transparent text-gray-500 hover:text-gray-300"
                    }`}
                  >
                    {s.title.split(" ")[0]}
                  </button>
                ))}
              </div>

              {/* Spotlight Title */}
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[10px] text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded font-bold border border-amber-500/20">
                    IMDb {current.rating}
                  </span>
                  <span className="text-xs text-gray-500 font-sans">• 4K HDR Atmos</span>
                </div>
                <h3 className="font-display font-black text-lg sm:text-xl text-white tracking-tight uppercase">
                  {current.title}
                </h3>
              </div>

              {/* Spotlight description */}
              <p className="font-sans text-xs text-gray-400 leading-relaxed min-h-[50px]">
                {current.desc}
              </p>

              {/* Tag badges */}
              <div className="flex flex-wrap gap-1.5 pt-2">
                {current.tags.map((t, i) => (
                  <span key={i} className="font-sans text-[9px] font-medium bg-[#141414] text-gray-400 px-2.5 py-1 rounded-md border border-gray-900/40">
                    {t}
                  </span>
                ))}
              </div>

            </div>

            {/* Dynamic catalog interactive footer */}
            <div className="bg-[#080808] px-6 py-4.5 border-t border-gray-950 flex items-center justify-between text-xs">
              <span className="font-sans text-gray-500 flex items-center space-x-1">
                <Flame className="w-3.5 h-3.5 text-red-500 fill-red-500" />
                <span>Popularidade Máxima</span>
              </span>
              <button 
                onClick={onScrollToPlans}
                className="font-display font-extrabold text-red-500 hover:text-red-400 transition-colors flex items-center space-x-1 cursor-pointer"
              >
                <span>VER PLANOS</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        </div>

      </div>

    </section>
  );
}

