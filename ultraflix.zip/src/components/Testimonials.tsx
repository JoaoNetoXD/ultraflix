import React from "react";
import { Star, ShieldCheck, Quote } from "lucide-react";
import { motion } from "motion/react";
import { TESTIMONIALS } from "../data";

export default function Testimonials() {
  return (
    <section className="py-20 px-4 bg-[#0a0a0a]">
      <div className="max-w-5xl mx-auto">
        
        {/* Header Title Area */}
        <div className="text-center mb-14">
          <p className="font-mono text-xs font-semibold tracking-widest text-red-500 uppercase mb-3">
            Satisfação Garantida
          </p>
          <h2 className="font-display font-black text-3xl sm:text-4xl text-white tracking-tight leading-tight uppercase">
            MILHARES DE PESSOAS JÁ APROVEITAM A ULTRAFLIX
          </h2>
          <div className="w-12 h-1 bg-red-600 mx-auto mt-4 rounded-full" />
          
          {/* Main 5.0 Stars Badge */}
          <div className="mt-6 inline-flex flex-col sm:flex-row items-center justify-center gap-3 bg-[#0d0d0d] border border-gray-900 px-6 py-4 rounded-2xl">
            <div className="flex items-center space-x-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className="w-5 h-5 fill-amber-500 text-amber-500" />
              ))}
            </div>
            <div className="text-center sm:text-left">
              <span className="font-display font-black text-lg text-white mr-2">5.0 / 5.0</span>
              <span className="font-sans text-xs text-gray-400 block sm:inline">com base em avaliações de clientes ativos</span>
            </div>
          </div>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {TESTIMONIALS.map((t, idx) => (
            <motion.div
              key={t.id}
              id={`testimonial_${t.id}`}
              initial={{ opacity: 0, scale: 0.96, y: 15 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: idx * 0.12 }}
              className="relative bg-[#0d0d0d] border border-gray-900/60 rounded-2xl p-6 flex flex-col justify-between hover:border-red-600/10 transition-all duration-200"
            >
              {/* Quote icon watermark */}
              <Quote className="absolute right-5 top-5 w-8 h-8 text-gray-950 stroke-[3px]" />

              {/* Star Rating & Comment */}
              <div>
                <div className="flex items-center space-x-0.5 mb-4">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star key={s} className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                  ))}
                </div>
                <p className="font-sans text-xs sm:text-sm text-gray-300 leading-relaxed italic mb-6">
                  "{t.comment}"
                </p>
              </div>

              {/* Customer Info */}
              <div className="flex items-center space-x-3 border-t border-gray-900/40 pt-4">
                {/* Real User Avatar with initials fallback */}
                <div className="w-10 h-10 rounded-full bg-red-950/40 border border-red-900/20 text-red-500 font-display font-extrabold text-xs sm:text-sm flex items-center justify-center overflow-hidden shrink-0">
                  {t.avatarUrl ? (
                    <img
                      src={t.avatarUrl}
                      alt={t.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    t.name.split(" ").map(n => n[0]).join("")
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-1">
                    <span className="font-display font-extrabold text-xs sm:text-sm text-white truncate">
                      {t.name}
                    </span>
                    {t.verified && (
                      <ShieldCheck className="w-4 h-4 text-emerald-500 fill-emerald-500/10 shrink-0" title="Assinante Verificado" />
                    )}
                  </div>
                  <span className="font-sans text-[10px] text-gray-500 block">
                    {t.location} • {t.date}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Placeholder banner for future client reviews */}
        <div className="bg-gradient-to-r from-red-950/20 via-[#0d0d0d] to-red-950/20 border border-red-950/20 rounded-2xl p-6 text-center">
          <p className="font-sans text-xs sm:text-sm text-gray-400">
            Fez sua assinatura e quer enviar seu depoimento? Nosso suporte está de braços abertos para receber seu feedback via WhatsApp!
          </p>
        </div>

      </div>
    </section>
  );
}
