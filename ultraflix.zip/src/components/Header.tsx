import React from "react";
import { Play } from "lucide-react";

interface HeaderProps {
  onScrollToPlans: () => void;
}

export default function Header({ onScrollToPlans }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#050505]/90 backdrop-blur-md border-b border-red-950/30">
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4 flex items-center justify-between">
        {/* Brand Logo */}
        <div 
          onClick={onScrollToPlans}
          className="flex items-center space-x-1 cursor-pointer select-none"
        >
          <div className="bg-red-600 p-1.5 rounded-lg flex items-center justify-center shadow-lg shadow-red-600/20">
            <Play className="w-5 h-5 fill-white text-white" />
          </div>
          <span className="font-display font-extrabold text-xl sm:text-2xl tracking-tighter text-white">
            ULTRA<span className="text-red-600 text-shadow-neon">FLIX</span>
          </span>
        </div>

        {/* Action button */}
        <button
          onClick={onScrollToPlans}
          id="btn_header_assinar"
          className="bg-red-600 hover:bg-red-700 active:scale-95 text-white font-display font-bold text-xs sm:text-sm px-4 py-2 sm:px-5 sm:py-2.5 rounded-full shadow-md shadow-red-600/30 hover:shadow-red-600/50 transition-all duration-200 uppercase tracking-wider"
        >
          Assinar Agora
        </button>
      </div>
    </header>
  );
}
