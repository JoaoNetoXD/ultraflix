import React, { useState, useEffect } from "react";
import { X, ShieldCheck, Lock, CreditCard, Sparkles, Copy, CheckCircle, Smartphone, Mail, User, Phone, Check, ArrowRight } from "lucide-react";
import { Plan, PaymentMethod, CheckoutForm } from "../types";

interface CheckoutModalProps {
  plan: Plan | null;
  onClose: () => void;
}

export default function CheckoutModal({ plan, onClose }: CheckoutModalProps) {
  if (!plan) return null;

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [form, setForm] = useState<CheckoutForm>({
    name: "",
    phone: "",
    paymentMethod: "pix",
    cardNumber: "",
    cardName: "",
    cardExpiry: "",
    cardCvv: "",
  });

  const [formErrors, setFormErrors] = useState<string>("");
  const [copiedPix, setCopiedPix] = useState(false);
  const [simulationCountdown, setSimulationCountdown] = useState(3);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
    setFormErrors("");
  };

  const selectPaymentMethod = (method: PaymentMethod) => {
    setForm({
      ...form,
      paymentMethod: method,
    });
  };

  const handleStep1Submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone) {
      setFormErrors("Por favor, preencha todos os campos cadastrais.");
      return;
    }
    setStep(2);
  };

  const handleConfirmPayment = () => {
    // Proceed to loading state
    setStep(3);
  };

  // Generate random credentials on success
  useEffect(() => {
    if (step === 3) {
      const interval = setInterval(() => {
        setSimulationCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            // generate random user details
            const firstName = form.name.split(" ")[0].toLowerCase().replace(/[^a-z0-9]/g, "");
            const randomNum = Math.floor(100 + Math.random() * 900);
            setUsername(`uf_${firstName}${randomNum}`);
            setPassword(Math.random().toString(36).substring(2, 10).toUpperCase());
            setStep(4);
            return 3;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [step, form.name]);

  const copyPixCode = () => {
    const code = plan.pixCode || "00020101021226850014br.gov.bcb.pix2563pix.ultraflix.com/checkout/id" + plan.id + Math.floor(100000 + Math.random() * 900000);
    navigator.clipboard.writeText(code);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-55 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
      {/* Container Card */}
      <div className="relative w-full max-w-lg bg-[#0d0d0d] border border-red-950/40 rounded-2.5xl overflow-hidden shadow-2xl shadow-red-600/5 my-auto flex flex-col">
        
        {/* Header Close Button (not visible in final success step to enforce focus) */}
        {step !== 3 && step !== 4 && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-500 hover:text-white bg-[#151515] p-1.5 rounded-full hover:scale-105 transition-all cursor-pointer z-10"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Modal Banner */}
        <div className="bg-gradient-to-r from-red-950/40 via-red-900/10 to-red-950/40 px-6 py-5 border-b border-gray-900 flex items-center space-x-3">
          <div className="bg-red-600 p-1 rounded-lg">
            <Sparkles className="w-4 h-4 text-white fill-white/20" />
          </div>
          <div>
            <h4 className="font-display font-extrabold text-sm sm:text-base text-white tracking-wide uppercase">
              Finalizar Assinatura
            </h4>
            <p className="font-sans text-[10px] sm:text-xs text-gray-400">
              Você escolheu o <strong className="text-red-500">{plan.title}</strong> por R$ {plan.price.toFixed(2)}
            </p>
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-gray-900 h-1">
          <div
            className="bg-red-600 h-1 transition-all duration-300"
            style={{ width: `${(step / 4) * 100}%` }}
          />
        </div>

        {/* Main interactive form space */}
        <div className="p-6 flex-1">
          
          {/* STEP 1: CONTACT DETAILS */}
          {step === 1 && (
            <form onSubmit={handleStep1Submit} className="space-y-4">
              <div className="text-center mb-6">
                <p className="font-display font-bold text-white text-base">
                  Crie sua conta ULTRAFLIX
                </p>
                <p className="font-sans text-xs text-gray-400 mt-1">
                  Precisamos desses dados para enviar suas credenciais de acesso instantaneamente.
                </p>
              </div>

              {formErrors && (
                <div className="bg-red-950/40 border border-red-600/30 text-red-400 p-3 rounded-xl text-xs text-center font-semibold">
                  {formErrors}
                </div>
              )}

              {/* Name Field */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-gray-400 font-display">Nome Completo</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-600" />
                  <input
                    type="text"
                    name="name"
                    value={form.name}
                    onChange={handleInputChange}
                    placeholder="Ex: João Silva Santos"
                    className="w-full bg-[#050505] border border-gray-900 rounded-xl py-3 pl-11 pr-4 text-xs sm:text-sm text-white placeholder-gray-600 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600/30 transition-all font-sans"
                    required
                  />
                </div>
              </div>

              {/* WhatsApp Field */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-gray-400 font-display">WhatsApp (para ativação rápida)</label>
                <div className="relative">
                  <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-600" />
                  <input
                    type="tel"
                    name="phone"
                    value={form.phone}
                    onChange={handleInputChange}
                    placeholder="Ex: (11) 99999-9999"
                    className="w-full bg-[#050505] border border-gray-900 rounded-xl py-3 pl-11 pr-4 text-xs sm:text-sm text-white placeholder-gray-600 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600/30 transition-all font-sans"
                    required
                  />
                </div>
              </div>

              {/* Proceed Button */}
              <button
                type="submit"
                className="w-full bg-red-600 hover:bg-red-700 active:scale-98 text-white py-4 rounded-xl font-display font-bold text-xs sm:text-sm uppercase tracking-wider transition-all duration-150 cursor-pointer flex items-center justify-center space-x-1"
              >
                <span>Avançar para Pagamento</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* STEP 2: PAYMENT METHOD */}
          {step === 2 && (
            <div className="space-y-5">
              <div className="text-center">
                <p className="font-display font-bold text-white text-base">
                  Pagamento via Pix
                </p>
                <p className="font-sans text-xs text-gray-400 mt-1">
                  Ativação automática instantânea da sua assinatura.
                </p>
              </div>

              {formErrors && (
                <div className="bg-red-950/40 border border-red-600/30 text-red-400 p-3 rounded-xl text-xs text-center font-semibold">
                  {formErrors}
                </div>
              )}

              {/* PIX AREA DETAILS */}
              <div className="bg-[#050505] border border-gray-900 rounded-2xl p-4 text-center space-y-4">
                <div className="flex justify-center">
                  {/* Real scannable high-fidelity QR Code generated from the exact Pix Copia e Cola code */}
                  <div className="bg-white p-3 rounded-2xl flex items-center justify-center shadow-lg shadow-black/40">
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&color=000000&data=${encodeURIComponent(plan.pixCode || '')}`}
                      alt="Pix QR Code"
                      referrerPolicy="no-referrer"
                      className="w-40 h-40 object-contain"
                    />
                  </div>
                </div>

                <p className="font-sans text-xs text-gray-400">
                  Clique no botão abaixo para copiar a chave Pix "Copia e Cola" e realize o pagamento no app do seu banco.
                </p>

                <button
                  type="button"
                  onClick={copyPixCode}
                  className="w-full bg-[#111111] border border-gray-800 hover:border-red-600/40 text-white font-sans text-xs py-3 px-4 rounded-xl flex items-center justify-center space-x-2 transition-all cursor-pointer active:scale-98"
                >
                  <Copy className="w-4 h-4 text-red-500" />
                  <span>{copiedPix ? "Chave copiada com sucesso!" : "Copiar Código Pix Copia e Cola"}</span>
                </button>

                <div className="text-center pt-2">
                  <span className="font-mono text-[10px] text-amber-500 bg-amber-950/20 px-3 py-1.5 rounded-full border border-amber-900/30">
                    ⚡ Ativação automática após o Pix
                  </span>
                </div>
              </div>

              {/* Action Confirmation Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleConfirmPayment}
                  className="w-full bg-red-600 hover:bg-red-700 active:scale-98 text-white py-4 rounded-xl font-display font-black text-xs sm:text-sm uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center space-x-1.5 shadow-lg shadow-red-600/20"
                >
                  <Lock className="w-4 h-4 text-white" />
                  <span>Já realizei o pagamento Pix</span>
                </button>
              </div>

              {/* Navigation Back button */}
              <button
                type="button"
                onClick={() => setStep(1)}
                className="w-full text-center text-xs text-gray-500 hover:text-white font-sans transition-colors cursor-pointer"
              >
                Voltar e alterar dados cadastrais
              </button>
            </div>
          )}

          {/* STEP 3: LOADING TRANSITION STATE */}
          {step === 3 && (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-6">
              {/* Spinner wheel */}
              <div className="w-16 h-16 border-4 border-gray-900 border-t-red-600 rounded-full animate-spin" />
              
              <div className="space-y-2">
                <p className="font-display font-bold text-lg text-white">
                  Processando sua assinatura...
                </p>
                <p className="font-sans text-xs text-gray-400 max-w-xs mx-auto">
                  Por favor, não feche esta janela. Estamos criando seu usuário e liberando seu acesso.
                </p>
              </div>

              {/* Simulated stage ticker */}
              <div className="bg-[#050505] border border-gray-950 px-4 py-2 rounded-lg font-mono text-[10px] text-red-500 animate-pulse">
                {simulationCountdown === 3 && "Verificando dados bancários..."}
                {simulationCountdown === 2 && "Cadastrando credenciais de acesso..."}
                {simulationCountdown === 1 && "Finalizando conexões ULTRAFLIX..."}
              </div>
            </div>
          )}

          {/* STEP 4: SUCCESS CREDENTIALS GENERATED */}
          {step === 4 && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-emerald-950/30 border border-emerald-500/20 text-emerald-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/10">
                  <CheckCircle className="w-6 h-6 stroke-[2.5]" />
                </div>
                <h3 className="font-display font-black text-xl text-white">
                  ASSINATURA ATIVADA!
                </h3>
                <p className="font-sans text-xs text-gray-400 mt-1">
                  Seu login foi liberado. Anote ou salve suas credenciais de acesso abaixo:
                </p>
              </div>

              {/* Credentials Box */}
              <div className="bg-gradient-to-b from-[#0e0e0e] to-[#0a0a0a] border border-gray-900 rounded-2xl p-5 space-y-4">
                <div className="space-y-1">
                  <span className="block text-[10px] font-mono text-gray-500 uppercase tracking-wider">Usuário</span>
                  <div className="bg-[#050505] px-4 py-3 rounded-xl flex items-center justify-between border border-gray-950">
                    <span className="font-mono text-xs sm:text-sm text-white font-semibold select-all">{username}</span>
                    <span className="text-[10px] bg-red-950/20 text-red-400 px-2 py-0.5 rounded font-sans uppercase">Salvo</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="block text-[10px] font-mono text-gray-500 uppercase tracking-wider">Senha de Acesso</span>
                  <div className="bg-[#050505] px-4 py-3 rounded-xl flex items-center justify-between border border-gray-950">
                    <span className="font-mono text-xs sm:text-sm text-white font-semibold select-all">{password}</span>
                    <span className="text-[10px] bg-red-950/20 text-red-400 px-2 py-0.5 rounded font-sans uppercase font-bold">Temporária</span>
                  </div>
                </div>
              </div>

              {/* Instructions steps */}
              <div className="space-y-2 text-xs text-gray-400 font-sans border-t border-gray-950 pt-4">
                <p className="font-display font-bold text-white text-xs mb-2">Próximos passos rápidos:</p>
                <div className="flex items-start space-x-2">
                  <div className="w-5 h-5 rounded-full bg-red-950/30 text-red-500 flex items-center justify-center font-mono text-[10px] font-bold shrink-0 mt-0.5">1</div>
                  <p>Enviamos as instruções completas de download para o seu número de WhatsApp <strong className="text-white">{form.phone}</strong>.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-5 h-5 rounded-full bg-red-950/30 text-red-500 flex items-center justify-center font-mono text-[10px] font-bold shrink-0 mt-0.5">2</div>
                  <p>Abra seu aplicativo ULTRAFLIX na Smart TV ou Celular e insira as credenciais acima para começar a assistir agora!</p>
                </div>
              </div>

              {/* Success Final CTA */}
              <button
                type="button"
                onClick={onClose}
                className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-display font-bold py-3.5 rounded-xl text-xs uppercase tracking-wider transition-all duration-150 cursor-pointer text-center"
              >
                Entendi, ir para a Plataforma!
              </button>
            </div>
          )}

        </div>

        {/* Safe Badge Footer (Only in step 1 & 2 for security reinforcement) */}
        {step < 3 && (
          <div className="bg-[#090909] py-3.5 px-6 border-t border-gray-950 flex items-center justify-between text-gray-500 text-[10px] sm:text-xs">
            <div className="flex items-center space-x-1">
              <ShieldCheck className="w-4 h-4 text-emerald-500 fill-emerald-500/10 shrink-0" />
              <span>Ambiente de Pagamento Seguro</span>
            </div>
            <span>Ativação Instantânea ⚡</span>
          </div>
        )}

      </div>
    </div>
  );
}
